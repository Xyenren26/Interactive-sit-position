// server.js
const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

const DATA_DIR = path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const POS_FILE = path.join(DATA_DIR, 'position.json');
const DET_FILE = path.join(DATA_DIR, 'details.json');

// Ensure data directory exists and provide initial sample files if missing
function ensureDataFiles() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

  if (!fs.existsSync(POS_FILE)) {
    const samplePos = {
      version: 1,
      areas: [],
      chairs: []
    };
    fs.writeFileSync(POS_FILE, JSON.stringify(samplePos, null, 2));
    console.log('Created', POS_FILE);
  }
  if (!fs.existsSync(DET_FILE)) {
    const sampleDet = { version: 1, chairs: [] };
    fs.writeFileSync(DET_FILE, JSON.stringify(sampleDet, null, 2));
    console.log('Created', DET_FILE);
  }
}

ensureDataFiles();

// Serve static files (frontend)
app.use('/', express.static(PUBLIC_DIR));

// GET raw JSON files (so frontend can load them)
app.get('/data/position.json', (req, res) => {
  res.sendFile(POS_FILE);
});
app.get('/data/details.json', (req, res) => {
  res.sendFile(DET_FILE);
});

// POST endpoints to save updated JSON
app.post('/savePositions', (req, res) => {
  const body = req.body;
  if (!body || typeof body !== 'object') {
    return res.status(400).json({ ok: false, message: 'Invalid JSON' });
  }
  try {
    fs.writeFileSync(POS_FILE, JSON.stringify(body, null, 2));
    return res.json({ ok: true, message: 'positions saved' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, message: 'write failed' });
  }
});

app.post('/saveDetails', (req, res) => {
  const body = req.body;
  if (!body || typeof body !== 'object') {
    return res.status(400).json({ ok: false, message: 'Invalid JSON' });
  }
  try {
    fs.writeFileSync(DET_FILE, JSON.stringify(body, null, 2));
    return res.json({ ok: true, message: 'details saved' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, message: 'write failed' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT} — serving ./public and ./data`);
});
